package com.boot.Controller;

import com.boot.Service.LikeService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.List;

@RestController
@RequiredArgsConstructor
@RequestMapping("/api/likes")
public class LikeController {

    private final LikeService likeService;

    // 좋아요 누르기
    @PostMapping
    public String addLike(@RequestBody HashMap<String, Object> param) {
        boolean result = likeService.addLike(param);
        return result ? "liked" : "already liked";
    }

    // 좋아요 취소
    @DeleteMapping
    public String removeLike(@RequestBody HashMap<String, Object> param) {
        boolean result = likeService.removeLike(param);
        return result ? "unliked" : "not liked yet";
    }

    // 좋아요 여부 확인
    @PostMapping("/isLiked")
    public boolean isLiked(@RequestBody HashMap<String, Object> param) {
        return likeService.isLiked(param);
    }

    // 좋아요 개수 조회
    @GetMapping("/count/{postId}")
    public int countLikes(@PathVariable int postId) {
        return likeService.countLikes(postId);
    }

    // (선택) 게시글별 좋아요 누른 유저 목록
    @GetMapping("/users/{postId}")
    public List<String> getLikeUsers(@PathVariable int postId) {
        return likeService.getLikeUsers(postId);
    }
}