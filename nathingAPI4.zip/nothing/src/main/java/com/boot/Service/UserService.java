package com.boot.Service;

import com.boot.DTO.UserDTO;
import com.boot.DTO.UserRegisterDTO;

import java.util.List;

public interface UserService {

    // 아이디 중복 여부 확인
    boolean isUsernameTaken(String username);

    // 닉네임 중복 여부 확인
    boolean isNicknameTaken(String nickname);

    // 회원가입 처리
    void registerUser(UserRegisterDTO dto);

    // 사용자 로그인
    UserDTO login(String username, String password);

    // 모든 사용자 조회 (관리자용)
    List<UserDTO> getAllUsers();

    // 사용자 역할 업데이트 (관리자용)
    void updateUserRole(int id, String role);

    // 사용자 삭제 (관리자용)
    void deleteUser(int id);

    // 관리자 권한 확인
    boolean isAdmin(UserDTO user);
}
