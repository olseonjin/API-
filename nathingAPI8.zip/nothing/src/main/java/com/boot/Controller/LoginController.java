package com.boot.Controller;

import com.boot.DTO.UserDTO;
import com.boot.DTO.UserRegisterDTO;
import com.boot.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.HashMap;
import java.util.Map;

@Controller
public class LoginController {

    @Autowired
    private UserService userService;

    // 로그인 폼 페이지
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    // 닉네임 존재 여부 확인 (AJAX용)
    @PostMapping("/api/check-nickname")
    @ResponseBody
    public Map<String, Object> checkNickname(@RequestParam String nickname) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            UserDTO existingUser = userService.findByNickname(nickname);
            boolean exists = existingUser != null;
            
            response.put("success", true);
            response.put("exists", exists);
            response.put("message", exists ? "닉네임이 존재합니다." : "새로운 닉네임입니다.");
            
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "닉네임 확인 중 오류가 발생했습니다.");
        }
        
        return response;
    }

    // 닉네임과 비밀번호로 로그인 처리
    @PostMapping("/login")
    public String login(@RequestParam String nickname,
                       @RequestParam String password,
                       HttpSession session,
                       Model model) {
        
        try {
            // 1. 닉네임으로 사용자 조회
            UserDTO existingUser = userService.findByNickname(nickname);
            
            if (existingUser == null) {
                // 닉네임이 없는 경우 - 자동 회원가입
                UserRegisterDTO newUser = new UserRegisterDTO();
                newUser.setNickname(nickname);
                newUser.setPassword(password);
                newUser.setUsername(nickname); // 닉네임을 아이디로도 사용
                newUser.setRole("USER");
                
                userService.registerUser(newUser);
                
                // 새로 생성된 사용자 정보로 세션 설정
                UserDTO createdUser = userService.findByNicknameAndPassword(nickname, password);
                session.setAttribute("user", createdUser);
                
                model.addAttribute("message", "새로운 사용자로 등록되었습니다. 입장합니다.");
                return "redirect:/";
                
            } else {
                // 닉네임이 있는 경우 - 비밀번호 확인
                UserDTO user = userService.findByNicknameAndPassword(nickname, password);
                
                if (user != null) {
                    // 비밀번호가 일치하는 경우
                    session.setAttribute("user", user);
                    
                    // 관리자인 경우 관리자 대시보드로, 일반 사용자는 메인 페이지로
                    if (userService.isAdmin(user)) {
                        return "redirect:/admin/dashboard";
                    } else {
                        model.addAttribute("message", "입장합니다.");
                        return "redirect:/";
                    }
                } else {
                    // 비밀번호가 틀린 경우
                    model.addAttribute("error", "입장불가: 비밀번호가 올바르지 않습니다.");
                    return "login";
                }
            }
        } catch (Exception e) {
            model.addAttribute("error", "로그인 처리 중 오류가 발생했습니다: " + e.getMessage());
            return "login";
        }
    }

    // 로그아웃
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    // 메인 페이지 (로그인 후 접근)
    @GetMapping("/")
    public String main(HttpSession session, Model model) {
        UserDTO user = (UserDTO) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("user", user);
        return "main";
    }
} 