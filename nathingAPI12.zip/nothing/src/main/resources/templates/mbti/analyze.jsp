<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>MBTI 분석</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        textarea, select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        textarea { height: 120px; resize: vertical; }
        .mbti-group { display: grid; grid-template-columns: repeat(2, 1fr); gap: 20px; margin-bottom: 20px; }
        .mbti-option { text-align: center; padding: 15px; border: 2px solid #ddd; border-radius: 8px; cursor: pointer; transition: all 0.3s; }
        .mbti-option:hover { border-color: #007bff; background-color: #f8f9fa; }
        .mbti-option.selected { border-color: #007bff; background-color: #e3f2fd; }
        .mbti-option input { display: none; }
        .btn { background-color: #007bff; color: white; padding: 15px 30px; border: none; border-radius: 4px; cursor: pointer; width: 100%; font-size: 16px; }
        .btn:hover { background-color: #0056b3; }
        .nav-links { text-align: center; margin-top: 20px; }
        .nav-links a { display: inline-block; margin: 0 10px; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 4px; }
        .nav-links a:hover { background: #545b62; }
    </style>
</head>
<body>
    <div class="container">
        <h1 style="text-align: center; margin-bottom: 30px;">MBTI 분석</h1>
        
        <form id="mbtiForm">
            <div class="form-group">
                <label for="content">게시글 내용:</label>
                <textarea id="content" name="content" placeholder="분석하고 싶은 내용을 입력하세요..." required></textarea>
            </div>
            
            <div class="form-group">
                <label for="category">감정 카테고리:</label>
                <select id="category" name="category" required>
                    <option value="">카테고리를 선택하세요</option>
                    <option value="기쁨">기쁨</option>
                    <option value="슬픔">슬픔</option>
                    <option value="분노">분노</option>
                    <option value="두려움">두려움</option>
                    <option value="놀람">놀람</option>
                    <option value="혐오">혐오</option>
                    <option value="수치심">수치심</option>
                    <option value="죄책감">죄책감</option>
                    <option value="사랑">사랑</option>
                    <option value="기대">기대</option>
                    <option value="기타">기타</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>E(외향) vs I(내향):</label>
                <div class="mbti-group">
                    <div class="mbti-option" onclick="selectOption(this, 'mE', 'E')">
                        <input type="radio" name="mE" value="E">
                        <strong>E - 외향적</strong><br>
                        <small>활발하고 사교적</small>
                    </div>
                    <div class="mbti-option" onclick="selectOption(this, 'mE', 'I')">
                        <input type="radio" name="mE" value="I">
                        <strong>I - 내향적</strong><br>
                        <small>차분하고 신중</small>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label>S(감각) vs N(직관):</label>
                <div class="mbti-group">
                    <div class="mbti-option" onclick="selectOption(this, 'mS', 'S')">
                        <input type="radio" name="mS" value="S">
                        <strong>S - 감각적</strong><br>
                        <small>현실적이고 구체적</small>
                    </div>
                    <div class="mbti-option" onclick="selectOption(this, 'mS', 'N')">
                        <input type="radio" name="mS" value="N">
                        <strong>N - 직관적</strong><br>
                        <small>창의적이고 추상적</small>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label>T(사고) vs F(감정):</label>
                <div class="mbti-group">
                    <div class="mbti-option" onclick="selectOption(this, 'mT', 'T')">
                        <input type="radio" name="mT" value="T">
                        <strong>T - 사고적</strong><br>
                        <small>논리적이고 객관적</small>
                    </div>
                    <div class="mbti-option" onclick="selectOption(this, 'mT', 'F')">
                        <input type="radio" name="mT" value="F">
                        <strong>F - 감정적</strong><br>
                        <small>공감적이고 주관적</small>
                    </div>
                </div>
            </div>
            
            <div class="form-group">
                <label>J(판단) vs P(인식):</label>
                <div class="mbti-group">
                    <div class="mbti-option" onclick="selectOption(this, 'mJ', 'J')">
                        <input type="radio" name="mJ" value="J">
                        <strong>J - 판단적</strong><br>
                        <small>계획적이고 체계적</small>
                    </div>
                    <div class="mbti-option" onclick="selectOption(this, 'mJ', 'P')">
                        <input type="radio" name="mJ" value="P">
                        <strong>P - 인식적</strong><br>
                        <small>유연하고 적응적</small>
                    </div>
                </div>
            </div>
            
            <button type="submit" class="btn">MBTI 분석하기</button>
        </form>
        
        <div class="nav-links">
            <a href="/mbti/stats">MBTI 통계</a>
            <a href="/mbti/user-stats">내 MBTI 통계</a>
            <a href="/">메인으로</a>
        </div>
    </div>

    <script>
        function selectOption(element, name, value) {
            // 같은 그룹의 다른 옵션들 선택 해제
            const group = element.parentElement;
            group.querySelectorAll('.mbti-option').forEach(opt => {
                opt.classList.remove('selected');
            });
            
            // 선택된 옵션 표시
            element.classList.add('selected');
            
            // 라디오 버튼 선택
            const radio = element.querySelector('input[type="radio"]');
            radio.checked = true;
        }

        document.getElementById('mbtiForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/mbti/analyze', {
                method: 'POST',
                body: new URLSearchParams(formData)
            })
            .then(response => response.text())
            .then(result => {
                if (result === 'success') {
                    alert('MBTI 분석이 완료되었습니다!');
                    window.location.href = '/mbti/stats';
                } else if (result === 'login_required') {
                    alert('로그인이 필요합니다.');
                    window.location.href = '/login';
                } else {
                    alert('분석 중 오류가 발생했습니다.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('오류가 발생했습니다.');
            });
        });
    </script>
</body>
</html>

