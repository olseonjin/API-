package com.boot.DAO;

import com.boot.DTO.UserDTO;
import com.boot.DTO.UserRegisterDTO;
import org.apache.ibatis.session.SqlSession;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Repository;

import java.util.List;

@Repository
public class UserDAOImpl implements UserDAO {

    @Autowired
    private SqlSession sqlSession;

    @Override
    public int checkUsername(String username) {
        return sqlSession.selectOne("com.boot.DAO.UserDAO.checkUsername", username);
    }

    @Override
    public int checkNickname(String nickname) {
        return sqlSession.selectOne("com.boot.DAO.UserDAO.checkNickname", nickname);
    }

    @Override
    public void insertUser(UserRegisterDTO dto) {
        sqlSession.insert("com.boot.DAO.UserDAO.insertUser", dto);
    }

    @Override
    public UserDTO findByNickname(String nickname) {
        return sqlSession.selectOne("com.boot.DAO.UserDAO.findByNickname", nickname);
    }

    @Override
    public UserDTO findByNicknameAndPassword(String nickname, String password) {
        UserDTO param = new UserDTO();
        param.setNickname(nickname);
        param.setPassword(password);
        return sqlSession.selectOne("com.boot.DAO.UserDAO.findByNicknameAndPassword", param);
    }

    @Override
    public UserDTO findByUsernameAndPassword(String username, String password) {
        UserDTO param = new UserDTO();
        param.setUsername(username);
        param.setPassword(password);
        return sqlSession.selectOne("com.boot.DAO.UserDAO.findByUsernameAndPassword", param);
    }

    @Override
    public List<UserDTO> getAllUsers() {
        return sqlSession.selectList("com.boot.DAO.UserDAO.getAllUsers");
    }

    @Override
    public void updateUserRole(int id, String role) {
        UserDTO param = new UserDTO();
        param.setId(id);
        param.setRole(role);
        sqlSession.update("com.boot.DAO.UserDAO.updateUserRole", param);
    }

    @Override
    public void deleteUser(int id) {
        sqlSession.delete("com.boot.DAO.UserDAO.deleteUser", id);
    }

	@Override
	public UserDTO findByUsername(String username) {
		// TODO Auto-generated method stub
		return null;
	}
}


