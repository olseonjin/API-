package com.boot.DAO;

import com.boot.DTO.UserDTO;
import com.boot.DTO.UserRegisterDTO;

import java.util.List;

public interface UserDAO {

    // 아이디 중복 체크
    int checkUsername(String username);

    // 닉네임 중복 체크
    int checkNickname(String nickname);

    // 회원 등록
    void insertUser(UserRegisterDTO dto);

    // 닉네임으로 사용자 조회
    UserDTO findByNickname(String nickname);

    // 닉네임과 비밀번호로 사용자 조회
    UserDTO findByNicknameAndPassword(String nickname, String password);

    // 사용자 로그인 (아이디/비밀번호로 사용자 조회)
    UserDTO findByUsernameAndPassword(String username, String password);

    // 모든 사용자 조회 (관리자용)
    List<UserDTO> getAllUsers();

    // 사용자 역할 업데이트 (관리자용)
    void updateUserRole(int id, String role);

    // 사용자 삭제 (관리자용)
    void deleteUser(int id);
}

