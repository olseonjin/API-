package com.boot.Controller;

import java.util.HashMap;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;

import com.boot.DTO.UserDTO;
import com.boot.DTO.UserRegisterDTO;
import com.boot.Service.UserService;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class LoginController {

    @Autowired
    private UserService userService;

    // 닉네임 존재 여부 확인
    @PostMapping("/check-nickname")
    public ResponseEntity<Map<String, Object>> checkNickname(@RequestParam String nickname) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            UserDTO existingUser = userService.findByNickname(nickname);
            boolean exists = existingUser != null;
            
            response.put("success", true);
            response.put("exists", exists);
            response.put("message", exists ? "닉네임이 존재합니다." : "새로운 닉네임입니다.");
            
            return ResponseEntity.ok(response);
            
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "닉네임 확인 중 오류가 발생했습니다.");
            return ResponseEntity.badRequest().body(response);
        }
    }

    // 닉네임과 비밀번호로 로그인/회원가입 처리
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestParam String nickname,
                                                   @RequestParam String password) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            // 1. 닉네임으로 사용자 조회
            UserDTO existingUser = userService.findByNickname(nickname);
            
            if (existingUser == null) {
                // 닉네임이 없는 경우 - 자동 회원가입
                UserRegisterDTO newUser = new UserRegisterDTO();
                newUser.setNickname(nickname);
                newUser.setPassword(password);
                newUser.setUsername(nickname); // 닉네임을 아이디로도 사용
                newUser.setRole("USER");
                
                userService.registerUser(newUser);
                
                // 새로 생성된 사용자 정보 조회
                UserDTO createdUser = userService.findByNicknameAndPassword(nickname, password);
                
                response.put("success", true);
                response.put("message", "새로운 사용자로 등록되었습니다.");
                response.put("user", createdUser);
                response.put("action", "register");
                
                return ResponseEntity.ok(response);
                
            } else {
                // 닉네임이 있는 경우 - 비밀번호 확인
                UserDTO user = userService.findByNicknameAndPassword(nickname, password);
                
                if (user != null) {
                    // 비밀번호가 일치하는 경우
                    response.put("success", true);
                    response.put("message", "로그인 성공");
                    response.put("user", user);
                    response.put("action", "login");
                    
                    return ResponseEntity.ok(response);
                    
                } else {
                    // 비밀번호가 틀린 경우
                    response.put("success", false);
                    response.put("error", "입장불가: 비밀번호가 올바르지 않습니다.");
                    response.put("action", "password_mismatch");
                    
                    return ResponseEntity.badRequest().body(response);
                }
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "로그인 처리 중 오류가 발생했습니다: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    // 사용자 정보 조회
    @GetMapping("/user/{nickname}")
    public ResponseEntity<Map<String, Object>> getUserInfo(@PathVariable String nickname) {
        Map<String, Object> response = new HashMap<>();
        
        try {
            UserDTO user = userService.findByNickname(nickname);
            
            if (user != null) {
                // 비밀번호는 제외하고 반환
                user.setPassword(null);
                
                response.put("success", true);
                response.put("user", user);
                
                return ResponseEntity.ok(response);
            } else {
                response.put("success", false);
                response.put("error", "사용자를 찾을 수 없습니다.");
                
                return ResponseEntity.notFound().build();
            }
            
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "사용자 정보 조회 중 오류가 발생했습니다.");
            return ResponseEntity.internalServerError().body(response);
        }
    }

    // 로그아웃 (Flutter에서는 클라이언트에서 세션 정리)
    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout() {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "로그아웃되었습니다.");
        
        return ResponseEntity.ok(response);
    }
} 