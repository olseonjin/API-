package com.boot.Controller;

import com.boot.DTO.PostDTO;
import com.boot.Service.PostService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/post")
public class PostController {

    @Autowired
    private PostService postService;

    // 전체 리스트
    @GetMapping("/list")
    public List<PostDTO> list() {
        return postService.list();
    }

    // 게시글 상세
    @GetMapping("/{id}")
    public PostDTO contentView(@PathVariable int id) {
        return postService.contentView(id);
    }

    // 게시글 작성
    @PostMapping("/write")
    public void write(@RequestBody PostDTO post) {
        postService.write(post);
    }

    // 게시글 수정
    @PutMapping("/modify")
    public void modify(@RequestBody PostDTO post) {
        postService.modify(post);
    }

    // 게시글 삭제
    @DeleteMapping("/delete/{id}")
    public void delete(@PathVariable int id) {
        postService.delete(id);
    }
}
