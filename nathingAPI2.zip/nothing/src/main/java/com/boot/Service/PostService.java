package com.boot.Service;

import com.boot.DTO.PostDTO;
import java.util.List;

public interface PostService {
    List<PostDTO> list();
    PostDTO contentView(int id);
    void write(PostDTO post);
    void modify(PostDTO post);
    void delete(int id);
}
