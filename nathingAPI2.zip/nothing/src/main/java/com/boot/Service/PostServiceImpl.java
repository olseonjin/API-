package com.boot.Service;

import com.boot.DAO.PostDAO;
import com.boot.DTO.PostDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;

@Service
public class PostServiceImpl implements PostService {

    @Autowired
    private PostDAO postDAO;

    @Override
    public List<PostDTO> list() {
        return postDAO.list();
    }

    @Override
    public PostDTO contentView(int id) {
        return postDAO.contentView(id);
    }

    @Override
    public void write(PostDTO post) {
        postDAO.write(post);
    }

    @Override
    public void modify(PostDTO post) {
        postDAO.modify(post);
    }

    @Override
    public void delete(int id) {
        postDAO.delete(id);
    }
}
