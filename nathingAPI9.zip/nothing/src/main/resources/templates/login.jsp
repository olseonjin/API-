<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>NA-Thing 로그인</title>
    <style>
        body { 
            font-family: Arial, sans-serif; 
            margin: 0; 
            padding: 20px; 
            background-color: #000; 
            color: white;
            display: flex;
            justify-content: center;
            align-items: center;
            min-height: 100vh;
        }
        .login-container { 
            max-width: 400px; 
            margin: 0 auto; 
            background: transparent; 
            padding: 30px; 
            text-align: center;
        }
        .logo {
            font-size: 2.5em;
            font-weight: bold;
            margin-bottom: 40px;
            color: white;
        }
        .form-group { 
            margin-bottom: 20px; 
            text-align: left;
        }
        label { 
            display: block; 
            margin-bottom: 5px; 
            font-weight: bold; 
            color: white;
        }
        input[type="text"], input[type="password"] { 
            width: 100%; 
            padding: 12px; 
            border: none; 
            border-radius: 25px; 
            box-sizing: border-box; 
            background: white;
            color: #000;
            font-size: 16px;
        }
        .btn { 
            background-color: white; 
            color: #000; 
            padding: 12px 20px; 
            border: none; 
            border-radius: 25px; 
            cursor: pointer; 
            width: 100%; 
            font-size: 16px;
            font-weight: bold;
            transition: all 0.3s ease;
        }
        .btn:hover { 
            background-color: #f0f0f0; 
            transform: translateY(-2px);
        }
        .btn:disabled {
            background-color: #666;
            color: #ccc;
            cursor: not-allowed;
            transform: none;
        }
        .error { 
            color: #ff6b6b; 
            margin-bottom: 15px; 
            background: rgba(255, 107, 107, 0.1);
            padding: 10px;
            border-radius: 5px;
        }
        .success { 
            color: #51cf66; 
            margin-bottom: 15px; 
            background: rgba(81, 207, 102, 0.1);
            padding: 10px;
            border-radius: 5px;
        }
        .forgot-password {
            color: white;
            text-decoration: none;
            font-size: 14px;
            margin-top: 10px;
            display: block;
        }
        .forgot-password:hover {
            text-decoration: underline;
        }
        .register-link { 
            text-align: center; 
            margin-top: 20px; 
            color: white;
        }
        .register-link a {
            color: white;
            text-decoration: none;
        }
        .register-link a:hover {
            text-decoration: underline;
        }
        .status-message {
            margin: 10px 0;
            padding: 10px;
            border-radius: 5px;
            font-weight: bold;
        }
    </style>
</head>
<body>
    <div class="login-container">
        <div class="logo">N NA-Thing</div>
        
        <% if (request.getAttribute("error") != null) { %>
            <div class="error">${error}</div>
        <% } %>
        
        <% if (request.getAttribute("message") != null) { %>
            <div class="success">${message}</div>
        <% } %>
        
        <form id="loginForm" action="/login" method="post">
            <div class="form-group">
                <label for="nickname">닉네임:</label>
                <input type="text" id="nickname" name="nickname" required>
            </div>
            
            <div class="form-group">
                <label for="password">비밀번호:</label>
                <input type="password" id="password" name="password" required>
            </div>
            
            <div id="statusMessage" class="status-message" style="display: none;"></div>
            
            <button type="submit" id="submitBtn" class="btn">로그인</button>
        </form>
        
        <a href="#" class="forgot-password">비밀번호를 잊으셨나요?</a>
        
        <div class="register-link">
            <a href="/user/register">회원가입</a>
        </div>
    </div>

    <script>
        document.getElementById('loginForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const nickname = document.getElementById('nickname').value;
            const password = document.getElementById('password').value;
            const submitBtn = document.getElementById('submitBtn');
            const statusMessage = document.getElementById('statusMessage');
            
            if (!nickname || !password) {
                showStatus('닉네임과 비밀번호를 모두 입력해주세요.', 'error');
                return;
            }
            
            // 닉네임 존재 여부 확인
            checkNickname(nickname, password);
        });
        
        function checkNickname(nickname, password) {
            const submitBtn = document.getElementById('submitBtn');
            const statusMessage = document.getElementById('statusMessage');
            
            // 닉네임 체크를 위한 API 호출
            submitBtn.disabled = true;
            submitBtn.textContent = '확인 중...';
            
            // FormData 생성
            const formData = new FormData();
            formData.append('nickname', nickname);
            
            // API 호출
            fetch('/api/check-nickname', {
                method: 'POST',
                body: formData
            })
            .then(response => response.json())
            .then(data => {
                if (data.success) {
                    if (data.exists) {
                        // 닉네임이 존재하는 경우 - 비밀번호 확인
                        submitBtn.textContent = '입장';
                        submitBtn.disabled = false;
                        showStatus('닉네임이 확인되었습니다. 입장하시겠습니까?', 'success');
                        
                        // 폼 제출 시 입장 처리
                        document.getElementById('loginForm').onsubmit = function(e) {
                            e.preventDefault();
                            submitForm(nickname, password);
                        };
                    } else {
                        // 닉네임이 없는 경우 - 자동 회원가입
                        submitBtn.textContent = '입장';
                        submitBtn.disabled = false;
                        showStatus('새로운 닉네임입니다. 자동으로 등록하고 입장합니다.', 'success');
                        
                        // 폼 제출 시 자동 회원가입 후 입장
                        document.getElementById('loginForm').onsubmit = function(e) {
                            e.preventDefault();
                            submitForm(nickname, password);
                        };
                    }
                } else {
                    showStatus(data.error || '닉네임 확인 중 오류가 발생했습니다.', 'error');
                    submitBtn.textContent = '로그인';
                    submitBtn.disabled = false;
                }
            })
            .catch(error => {
                console.error('Error:', error);
                showStatus('닉네임 확인 중 오류가 발생했습니다.', 'error');
                submitBtn.textContent = '로그인';
                submitBtn.disabled = false;
            });
        }
        
        function submitForm(nickname, password) {
            const form = document.getElementById('loginForm');
            const submitBtn = document.getElementById('submitBtn');
            
            submitBtn.disabled = true;
            submitBtn.textContent = '입장 중...';
            
            // 실제 폼 제출
            form.submit();
        }
        
        function showStatus(message, type) {
            const statusMessage = document.getElementById('statusMessage');
            statusMessage.textContent = message;
            statusMessage.className = `status-message ${type}`;
            statusMessage.style.display = 'block';
        }
        
        // 입력 필드 변경 시 상태 초기화
        document.getElementById('nickname').addEventListener('input', function() {
            const submitBtn = document.getElementById('submitBtn');
            const statusMessage = document.getElementById('statusMessage');
            
            submitBtn.textContent = '로그인';
            submitBtn.disabled = false;
            statusMessage.style.display = 'none';
        });
        
        document.getElementById('password').addEventListener('input', function() {
            const submitBtn = document.getElementById('submitBtn');
            const statusMessage = document.getElementById('statusMessage');
            
            submitBtn.textContent = '로그인';
            submitBtn.disabled = false;
            statusMessage.style.display = 'none';
        });
    </script>
</body>
</html> 