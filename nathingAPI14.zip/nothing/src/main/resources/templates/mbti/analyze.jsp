<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>MBTI 분석</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .form-group { margin-bottom: 20px; }
        label { display: block; margin-bottom: 5px; font-weight: bold; }
        textarea, select { width: 100%; padding: 10px; border: 1px solid #ddd; border-radius: 4px; box-sizing: border-box; }
        textarea { height: 120px; resize: vertical; }
        .slider-container { display: flex; align-items: center; gap: 10px; margin: 10px 0; }
        .slider { flex: 1; height: 6px; border-radius: 3px; background: #ddd; outline: none; }
        .slider::-webkit-slider-thumb { appearance: none; width: 20px; height: 20px; border-radius: 50%; background: #007bff; cursor: pointer; }
        .slider::-moz-range-thumb { width: 20px; height: 20px; border-radius: 50%; background: #007bff; cursor: pointer; border: none; }
        .slider-label { font-weight: bold; min-width: 20px; text-align: center; }
        .btn { background-color: #007bff; color: white; padding: 15px 30px; border: none; border-radius: 4px; cursor: pointer; width: 100%; font-size: 16px; }
        .btn:hover { background-color: #0056b3; }
        .nav-links { text-align: center; margin-top: 20px; }
        .nav-links a { display: inline-block; margin: 0 10px; padding: 10px 20px; background: #6c757d; color: white; text-decoration: none; border-radius: 4px; }
        .nav-links a:hover { background: #545b62; }
    </style>
</head>
<body>
    <div class="container">
        <h1 style="text-align: center; margin-bottom: 30px;">MBTI 분석</h1>
        
        <form id="mbtiForm">
            <div class="form-group">
                <label for="content">게시글 내용:</label>
                <textarea id="content" name="content" placeholder="분석하고 싶은 내용을 입력하세요..." required></textarea>
            </div>
            
            <div class="form-group">
                <label for="category">감정 카테고리:</label>
                <select id="category" name="category" required>
                    <option value="">카테고리를 선택하세요</option>
                    <option value="기쁨">기쁨</option>
                    <option value="슬픔">슬픔</option>
                    <option value="분노">분노</option>
                    <option value="두려움">두려움</option>
                    <option value="놀람">놀람</option>
                    <option value="혐오">혐오</option>
                    <option value="수치심">수치심</option>
                    <option value="죄책감">죄책감</option>
                    <option value="사랑">사랑</option>
                    <option value="기대">기대</option>
                    <option value="기타">기타</option>
                </select>
            </div>
            
            <div class="form-group">
                <label>E(외향) vs I(내향): <span id="mE-value">50</span></label>
                <div class="slider-container">
                    <span class="slider-label">E</span>
                    <input type="range" id="mE" name="mE" min="0" max="100" value="50" class="slider" oninput="updateSliderValue('mE', this.value)">
                    <span class="slider-label">I</span>
                </div>
            </div>
            
            <div class="form-group">
                <label>S(감각) vs N(직관): <span id="mS-value">50</span></label>
                <div class="slider-container">
                    <span class="slider-label">S</span>
                    <input type="range" id="mS" name="mS" min="0" max="100" value="50" class="slider" oninput="updateSliderValue('mS', this.value)">
                    <span class="slider-label">N</span>
                </div>
            </div>
            
            <div class="form-group">
                <label>T(사고) vs F(감정): <span id="mT-value">50</span></label>
                <div class="slider-container">
                    <span class="slider-label">T</span>
                    <input type="range" id="mT" name="mT" min="0" max="100" value="50" class="slider" oninput="updateSliderValue('mT', this.value)">
                    <span class="slider-label">F</span>
                </div>
            </div>
            
            <div class="form-group">
                <label>J(판단) vs P(인식): <span id="mJ-value">50</span></label>
                <div class="slider-container">
                    <span class="slider-label">J</span>
                    <input type="range" id="mJ" name="mJ" min="0" max="100" value="50" class="slider" oninput="updateSliderValue('mJ', this.value)">
                    <span class="slider-label">P</span>
                </div>
            </div>
            
            <button type="submit" class="btn">MBTI 분석하기</button>
        </form>
        
        <div class="nav-links">
            <a href="/mbti/stats">MBTI 통계</a>
            <a href="/mbti/user-stats">내 MBTI 통계</a>
            <a href="/">메인으로</a>
        </div>
    </div>

    <script>
        function updateSliderValue(sliderId, value) {
            document.getElementById(sliderId + '-value').textContent = value;
        }

        document.getElementById('mbtiForm').addEventListener('submit', function(e) {
            e.preventDefault();
            
            const formData = new FormData(this);
            
            fetch('/mbti/analyze', {
                method: 'POST',
                body: new URLSearchParams(formData)
            })
            .then(response => response.text())
            .then(result => {
                if (result === 'success') {
                    alert('MBTI 분석이 완료되었습니다!');
                    window.location.href = '/mbti/stats';
                } else if (result === 'login_required') {
                    alert('로그인이 필요합니다.');
                    window.location.href = '/login';
                } else {
                    alert('분석 중 오류가 발생했습니다.');
                }
            })
            .catch(error => {
                console.error('Error:', error);
                alert('오류가 발생했습니다.');
            });
        });
    </script>
</body>
</html>

