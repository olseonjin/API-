package com.boot.DTO;

public class UserRegisterDTO {
    private String username;
    private String nickname;
    private String password;
    private String role; // 추가: 사용자 역할 (USER, ADMIN)

    // 기본 생성자
    public UserRegisterDTO() {}

    // 전체 생성자
    public UserRegisterDTO(String username, String nickname, String password, String role) {
        this.username = username;
        this.nickname = nickname;
        this.password = password;
        this.role = role;
    }

    // Getters & Setters
    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }
}
