package com.boot.DTO;

import java.util.Date;

public class PostDTO {
    private int id;
    private String content;
    private String imageUrl;
    private String userNickname;
    private Date createdAt;
    private Date exitedAt;         // 종료 시간 추가
    private int likeCount;         // 좋아요 수 추가
    
    // MBTI 관련 필드들 추가
    private String category;       // 게시글 카테고리
    private int mE;               // E(0) vs I(100) - 0~100 점수
    private int mS;               // S(0) vs N(100) - 0~100 점수
    private int mT;               // T(0) vs F(100) - 0~100 점수
    private int mJ;               // J(0) vs P(100) - 0~100 점수

    public PostDTO() {}

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getUserNickname() { return userNickname; }
    public void setUserNickname(String userNickname) { this.userNickname = userNickname; }

    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }

    public Date getExitedAt() { return exitedAt; }
    public void setExitedAt(Date exitedAt) { this.exitedAt = exitedAt; }

    public int getLikeCount() { return likeCount; }
    public void setLikeCount(int likeCount) { this.likeCount = likeCount; }

    // MBTI 관련 getter/setter
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public int getME() { return mE; }
    public void setME(int mE) { this.mE = mE; }

    public int getMS() { return mS; }
    public void setMS(int mS) { this.mS = mS; }

    public int getMT() { return mT; }
    public void setMT(int mT) { this.mT = mT; }

    public int getMJ() { return mJ; }
    public void setMJ(int mJ) { this.mJ = mJ; }
}
