package com.boot.Controller;

import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.ResponseBody;

import com.boot.Service.PostService;
import com.boot.Service.UserService;

import lombok.RequiredArgsConstructor;

@Controller
@RequestMapping("/mbti")
@RequiredArgsConstructor
public class MbtiController {

    private final PostService postService;
    private final UserService userService;

    // MBTI 통계 대시보드
    @GetMapping("/stats")
    public String showMbtiStats(Model model) {
        List<Map<String, Object>> mbtiStats = postService.getMbtiStats();
        model.addAttribute("mbtiStats", mbtiStats);
        return "mbti/stats";
    }

    // 카테고리별 게시글 조회
    @GetMapping("/category/{category}")
    public String getPostsByCategory(@PathVariable String category, Model model) {
        List<com.boot.DTO.PostDTO> posts = postService.getPostsByCategory(category);
        model.addAttribute("posts", posts);
        model.addAttribute("category", category);
        return "mbti/category-posts";
    }

    // MBTI 분석 페이지
    @GetMapping("/analyze")
    public String showMbtiAnalyze() {
        return "mbti/analyze";
    }

    // MBTI 분석 결과 처리
    @PostMapping("/analyze")
    @ResponseBody
    public String analyzeMbti(@RequestParam String content, 
                             @RequestParam String category,
                             @RequestParam int mE,
                             @RequestParam int mS,
                             @RequestParam int mT,
                             @RequestParam int mJ,
                             HttpSession session) {
        
        // 세션에서 사용자 정보 확인
        com.boot.DTO.UserDTO currentUser = (com.boot.DTO.UserDTO) session.getAttribute("user");
        if (currentUser == null) {
            return "login_required";
        }

        try {
            // 게시글 작성 시 MBTI 정보 포함
            java.util.HashMap<String, Object> param = new java.util.HashMap<>();
            param.put("content", content);
            param.put("category", category);
            param.put("m_e", mE);
            param.put("m_s", mS);
            param.put("m_t", mT);
            param.put("m_j", mJ);
            param.put("user_nickname", currentUser.getNickname());
            
            postService.write(param);
            
            return "success";
        } catch (Exception e) {
            return "error";
        }
    }

    // 사용자별 MBTI 통계
    @GetMapping("/user-stats")
    public String showUserMbtiStats(HttpSession session, Model model) {
        com.boot.DTO.UserDTO currentUser = (com.boot.DTO.UserDTO) session.getAttribute("user");
        if (currentUser == null) {
            return "redirect:/login";
        }

        model.addAttribute("user", currentUser);
        return "mbti/user-stats";
    }

    // MBTI 요소별 상세 분석
    @GetMapping("/element/{element}")
    public String showElementAnalysis(@PathVariable String element, Model model) {
        List<Map<String, Object>> mbtiStats = postService.getMbtiStats();
        
        // 특정 요소의 통계만 필터링
        for (Map<String, Object> stat : mbtiStats) {
            if (element.equals(stat.get("mbti_element"))) {
                model.addAttribute("elementStats", stat);
                break;
            }
        }
        
        model.addAttribute("element", element);
        return "mbti/element-analysis";
    }
}

