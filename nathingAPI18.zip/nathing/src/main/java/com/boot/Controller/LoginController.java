package com.boot.Controller;

import com.boot.DTO.UserDTO;
import com.boot.DTO.UserRegisterDTO;
import com.boot.DTO.LoginRequestDTO;
import com.boot.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.HashMap;
import java.util.Map;

@RestController
@RequestMapping("/api")
@CrossOrigin(origins = "*")
public class LoginController {

    @Autowired
    private UserService userService;

    // 닉네임 존재 여부 확인
    @PostMapping("/check-nickname")
    public ResponseEntity<Map<String, Object>> checkNickname(@RequestParam String nickname) {
        Map<String, Object> response = new HashMap<>();
        try {
            UserDTO existingUser = userService.findByNickname(nickname);
            boolean exists = existingUser != null;
            response.put("success", true);
            response.put("exists", exists);
            response.put("message", exists ? "닉네임이 존재합니다." : "새로운 닉네임입니다.");
            return ResponseEntity.ok(response);
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "닉네임 확인 중 오류가 발생했습니다.");
            return ResponseEntity.badRequest().body(response);
        }
    }

    // x-www-form-urlencoded 로그인/회원가입 처리
    @PostMapping("/login")
    public ResponseEntity<Map<String, Object>> login(@RequestParam String nickname,
                                                    @RequestParam String password) {
        return handleLogin(nickname, password);
    }

    // application/json 로그인/회원가입 처리
    @PostMapping(value = "/login/json", consumes = MediaType.APPLICATION_JSON_VALUE)
    public ResponseEntity<Map<String, Object>> loginJson(@RequestBody LoginRequestDTO request) {
        return handleLogin(request.getNickname(), request.getPassword());
    }

    private ResponseEntity<Map<String, Object>> handleLogin(String rawNickname, String rawPassword) {
        Map<String, Object> response = new HashMap<>();
        try {
            String nickname = rawNickname == null ? null : rawNickname.trim();
            String password = rawPassword == null ? null : rawPassword.trim();

            if (nickname == null || nickname.isEmpty() || password == null || password.isEmpty()) {
                response.put("success", false);
                response.put("error", "nickname과 password는 필수입니다.");
                return ResponseEntity.badRequest().body(response);
            }

            UserDTO existingUser = userService.findByNickname(nickname);
            if (existingUser == null) {
                // 신규 회원가입
                UserRegisterDTO newUser = new UserRegisterDTO();
                newUser.setNickname(nickname);
                newUser.setPassword(password);
                newUser.setUsername(nickname); // userid는 닉네임으로 저장
                newUser.setRole("USER");
                userService.registerUser(newUser);

                UserDTO createdUser = userService.login(nickname, password);
                response.put("success", true);
                response.put("message", "새로운 사용자로 등록되었습니다.");
                response.put("user", createdUser);
                response.put("action", "register");
                return ResponseEntity.ok(response);
            } else {
                // 로그인 처리
                UserDTO user = userService.login(nickname, password);
                if (user != null) {
                    response.put("success", true);
                    response.put("message", "로그인 성공");
                    response.put("user", user);
                    response.put("action", "login");
                    return ResponseEntity.ok(response);
                } else {
                    response.put("success", false);
                    response.put("error", "입장불가: 비밀번호가 올바르지 않습니다.");
                    response.put("action", "password_mismatch");
                    return ResponseEntity.badRequest().body(response);
                }
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "로그인 처리 중 오류가 발생했습니다: " + e.getMessage());
            return ResponseEntity.internalServerError().body(response);
        }
    }

    // 사용자 정보 조회
    @GetMapping("/user/{nickname}")
    public ResponseEntity<Map<String, Object>> getUserInfo(@PathVariable String nickname) {
        Map<String, Object> response = new HashMap<>();
        try {
            UserDTO user = userService.findByNickname(nickname);
            if (user != null) {
                user.setPassword(null); // 비밀번호는 숨김
                response.put("success", true);
                response.put("user", user);
                return ResponseEntity.ok(response);
            } else {
                response.put("success", false);
                response.put("error", "사용자를 찾을 수 없습니다.");
                return ResponseEntity.notFound().build();
            }
        } catch (Exception e) {
            response.put("success", false);
            response.put("error", "사용자 정보 조회 중 오류가 발생했습니다.");
            return ResponseEntity.internalServerError().body(response);
        }
    }

    // 로그아웃 (stateless)
    @PostMapping("/logout")
    public ResponseEntity<Map<String, Object>> logout() {
        Map<String, Object> response = new HashMap<>();
        response.put("success", true);
        response.put("message", "로그아웃되었습니다.");
        return ResponseEntity.ok(response);
    }
}
