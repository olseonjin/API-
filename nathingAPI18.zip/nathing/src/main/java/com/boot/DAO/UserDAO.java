package com.boot.DAO;

import com.boot.DTO.UserDTO;
import com.boot.DTO.UserRegisterDTO;

import java.util.List;

public interface UserDAO {
    int checkUsername(String username);
    int checkNickname(String nickname);
    void insertUser(UserRegisterDTO dto);
    UserDTO findByNickname(String nickname);
    UserDTO findByUsername(String username);
    List<UserDTO> getAllUsers();
    void updateUserRole(int id, String role);
    void deleteUser(int id);
	UserDTO findByNicknameAndPassword(String nickname, String password);
	UserDTO findByUsernameAndPassword(String username, String password);
}

