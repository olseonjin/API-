package com.boot.DAO;

import com.boot.DTO.PostDTO;
import org.apache.ibatis.annotations.Mapper;
import java.util.List;
import java.util.HashMap;
import java.util.Map;

@Mapper
public interface PostDAO {
    List<PostDTO> list();
    void write(HashMap<String, Object> param);
    PostDTO contentView(HashMap<String, String> param);
    void modify(HashMap<String, Object> param);
    void delete(HashMap<String, String> param);
    
    // MBTI 관련 메서드들 추가
    List<Map<String, Object>> getMbtiStats();
    List<PostDTO> getPostsByCategory(String category);
}
