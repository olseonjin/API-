<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>메인 페이지</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
        .container { max-width: 800px; margin: 0 auto; }
        .header { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .content { background: white; padding: 30px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .btn { padding: 10px 20px; border: none; border-radius: 4px; cursor: pointer; text-decoration: none; display: inline-block; margin: 5px; }
        .btn-primary { background-color: #007bff; color: white; }
        .btn-success { background-color: #28a745; color: white; }
        .btn:hover { opacity: 0.8; }
        .logout { float: right; }
        .welcome { margin-bottom: 20px; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>메인 페이지</h1>
            <div class="logout">
                <span>안녕하세요, ${user.nickname}님</span>
                <a href="/logout" class="btn btn-primary">로그아웃</a>
            </div>
        </div>
        
        <div class="content">
            <div class="welcome">
                <h2>환영합니다!</h2>
                <p>사용자 정보:</p>
                <ul>
                    <li><strong>아이디:</strong> ${user.username}</li>
                    <li><strong>닉네임:</strong> ${user.nickname}</li>
                    <li><strong>역할:</strong> ${user.role == 'ADMIN' ? '관리자' : '일반 사용자'}</li>
                    <li><strong>가입일:</strong> ${user.createdAt}</li>
                </ul>
            </div>
            
            <div>
                <h3>사용 가능한 기능:</h3>
                <a href="/post" class="btn btn-success">게시글 보기</a>
                <a href="/user/profile" class="btn btn-primary">프로필 수정</a>
                
                <c:if test="${user.role == 'ADMIN'}">
                    <a href="/admin/dashboard" class="btn btn-success">관리자 대시보드</a>
                </c:if>
            </div>
        </div>
    </div>
</body>
</html> 