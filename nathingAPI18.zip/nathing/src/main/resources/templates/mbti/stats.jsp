<%@ page language="java" contentType="text/html; charset=UTF-8" pageEncoding="UTF-8"%>
<%@ taglib prefix="c" uri="http://java.sun.com/jsp/jstl/core" %>
<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>MBTI 통계 대시보드</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 0; padding: 20px; background-color: #f5f5f5; }
        .container { max-width: 1200px; margin: 0 auto; }
        .header { background: white; padding: 20px; border-radius: 8px; margin-bottom: 20px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .stats-grid { display: grid; grid-template-columns: repeat(auto-fit, minmax(300px, 1fr)); gap: 20px; margin-bottom: 20px; }
        .stat-card { background: white; padding: 20px; border-radius: 8px; box-shadow: 0 2px 10px rgba(0,0,0,0.1); }
        .stat-title { font-size: 18px; font-weight: bold; margin-bottom: 15px; color: #333; }
        .stat-item { display: flex; justify-content: space-between; margin-bottom: 10px; padding: 10px; background: #f8f9fa; border-radius: 4px; }
        .stat-label { font-weight: bold; }
        .stat-value { color: #007bff; }
        .nav-links { text-align: center; margin-top: 20px; }
        .nav-links a { display: inline-block; margin: 0 10px; padding: 10px 20px; background: #007bff; color: white; text-decoration: none; border-radius: 4px; }
        .nav-links a:hover { background: #0056b3; }
    </style>
</head>
<body>
    <div class="container">
        <div class="header">
            <h1>MBTI 통계 대시보드</h1>
            <p>게시글의 MBTI 요소별 통계를 확인할 수 있습니다.</p>
        </div>

        <div class="stats-grid">
            <c:forEach var="stat" items="${mbtiStats}">
                <div class="stat-card">
                    <div class="stat-title">${stat.mbti_element}</div>
                    <div class="stat-item">
                        <span class="stat-label">${stat.value}</span>
                        <span class="stat-value">${stat.post_count}개 게시글</span>
                    </div>
                    <div class="stat-item">
                        <span class="stat-label">평균 좋아요</span>
                        <span class="stat-value">${stat.avg_likes}</span>
                    </div>
                </div>
            </c:forEach>
        </div>

        <div class="nav-links">
            <a href="/mbti/analyze">MBTI 분석하기</a>
            <a href="/mbti/user-stats">내 MBTI 통계</a>
            <a href="/">메인으로</a>
        </div>
    </div>
</body>
</html>

