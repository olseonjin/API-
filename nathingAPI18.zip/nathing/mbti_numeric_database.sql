-- =====================================================
-- MBTI 기반 소셜 미디어 플랫폼 데이터베이스 (수치형 MBTI)
-- =====================================================

-- 1단계: 데이터베이스 생성 및 사용
DROP SCHEMA IF EXISTS nathing;
CREATE SCHEMA nathing;
USE nathing;

-- 2단계: 사용자 테이블 생성 (수치형 MBTI)
CREATE TABLE user (
    id INT PRIMARY KEY AUTO_INCREMENT,
    userid VARCHAR(20) NOT NULL UNIQUE,
    user_nickname VARCHAR(20) NOT NULL UNIQUE,
    password VARCHAR(60) NOT NULL,
    avg_m_e INT DEFAULT 50 COMMENT '평균 E(0) vs I(100) - 0~100 점수',
    avg_m_s INT DEFAULT 50 COMMENT '평균 S(0) vs N(100) - 0~100 점수',
    avg_m_t INT DEFAULT 50 COMMENT '평균 T(0) vs F(100) - 0~100 점수',
    avg_m_j INT DEFAULT 50 COMMENT '평균 J(0) vs P(100) - 0~100 점수',
    mbti_count INT DEFAULT 0 COMMENT 'MBTI 분석 횟수',
    role VARCHAR(20) DEFAULT 'USER',
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP
);

-- 3단계: 게시글 테이블 생성 (수치형 MBTI)
CREATE TABLE post (
    id INT PRIMARY KEY AUTO_INCREMENT,
    content TEXT NOT NULL,
    image_url VARCHAR(255),
    user_nickname VARCHAR(20) NOT NULL,
    category VARCHAR(50),
    m_e INT COMMENT 'E(0) vs I(100) - 0~100 점수',
    m_s INT COMMENT 'S(0) vs N(100) - 0~100 점수',
    m_t INT COMMENT 'T(0) vs F(100) - 0~100 점수',
    m_j INT COMMENT 'J(0) vs P(100) - 0~100 점수',
    like_count INT DEFAULT 0,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    exited_at DATETIME,
    CONSTRAINT fk_post_user_nickname
      FOREIGN KEY (user_nickname) REFERENCES user(user_nickname)
      ON DELETE CASCADE
);

-- 4단계: 좋아요 테이블 생성
CREATE TABLE post_like (
    id INT PRIMARY KEY AUTO_INCREMENT,
    post_id INT NOT NULL,
    user_nickname VARCHAR(20) NOT NULL,
    created_at DATETIME DEFAULT CURRENT_TIMESTAMP,
    CONSTRAINT fk_like_post FOREIGN KEY (post_id) REFERENCES post(id) ON DELETE CASCADE,
    CONSTRAINT fk_like_user FOREIGN KEY (user_nickname) REFERENCES user(user_nickname) ON DELETE CASCADE,
    UNIQUE KEY unique_like (post_id, user_nickname)
);

-- 5단계: 인덱스 생성
CREATE INDEX idx_post_m_e ON post(m_e);
CREATE INDEX idx_post_m_s ON post(m_s);
CREATE INDEX idx_post_m_t ON post(m_t);
CREATE INDEX idx_post_m_j ON post(m_j);
CREATE INDEX idx_post_category ON post(category);
CREATE INDEX idx_user_avg_m_e ON user(avg_m_e);
CREATE INDEX idx_user_avg_m_s ON user(avg_m_s);
CREATE INDEX idx_user_avg_m_t ON user(avg_m_t);
CREATE INDEX idx_user_avg_m_j ON user(avg_m_j);

-- 6단계: 제약조건 설정 (0~100 범위)
ALTER TABLE user 
ADD CONSTRAINT chk_user_m_e CHECK (avg_m_e >= 0 AND avg_m_e <= 100),
ADD CONSTRAINT chk_user_m_s CHECK (avg_m_s >= 0 AND avg_m_s <= 100),
ADD CONSTRAINT chk_user_m_t CHECK (avg_m_t >= 0 AND avg_m_t <= 100),
ADD CONSTRAINT chk_user_m_j CHECK (avg_m_j >= 0 AND avg_m_j <= 100);

ALTER TABLE post 
ADD CONSTRAINT chk_m_e CHECK (m_e >= 0 AND m_e <= 100),
ADD CONSTRAINT chk_m_s CHECK (m_s >= 0 AND m_s <= 100),
ADD CONSTRAINT chk_m_t CHECK (m_t >= 0 AND m_t <= 100),
ADD CONSTRAINT chk_m_j CHECK (m_j >= 0 AND m_j <= 100);

ALTER TABLE post 
ADD CONSTRAINT chk_category 
CHECK (category IN ('기쁨','슬픔','분노','두려움','놀람','혐오','수치심','죄책감','사랑','기대','기타'));

-- 7단계: 트리거 생성
DELIMITER //

CREATE TRIGGER trg_set_exited_at
BEFORE INSERT ON post
FOR EACH ROW
BEGIN
  IF NEW.exited_at IS NULL THEN
    SET NEW.exited_at = DATE_ADD(NOW(), INTERVAL 1 MINUTE);
  END IF;
END //

CREATE TRIGGER trg_update_user_avg_mbti
AFTER INSERT ON post
FOR EACH ROW
BEGIN
    IF NEW.m_e IS NOT NULL AND NEW.m_s IS NOT NULL 
       AND NEW.m_t IS NOT NULL AND NEW.m_j IS NOT NULL THEN
        
        -- 평균 계산 (기존 값과 새 값의 평균)
        UPDATE user 
        SET avg_m_e = (avg_m_e * mbti_count + NEW.m_e) / (mbti_count + 1),
            avg_m_s = (avg_m_s * mbti_count + NEW.m_s) / (mbti_count + 1),
            avg_m_t = (avg_m_t * mbti_count + NEW.m_t) / (mbti_count + 1),
            avg_m_j = (avg_m_j * mbti_count + NEW.m_j) / (mbti_count + 1),
            mbti_count = mbti_count + 1
        WHERE user_nickname = NEW.user_nickname;
    END IF;
END //

DELIMITER ;

-- 8단계: 이벤트 생성
SET GLOBAL event_scheduler = ON;

CREATE EVENT IF NOT EXISTS delete_expired_posts
ON SCHEDULE EVERY 1 MINUTE
DO
  DELETE FROM post WHERE exited_at < NOW();

-- 9단계: 뷰 생성 (수치형 MBTI 통계)
CREATE VIEW mbti_element_stats AS
SELECT 'E vs I' as mbti_element, 
       CASE WHEN m_e <= 50 THEN 'E' ELSE 'I' END as value,
       COUNT(*) as post_count, 
       AVG(like_count) as avg_likes,
       AVG(m_e) as avg_score
FROM post WHERE m_e IS NOT NULL GROUP BY CASE WHEN m_e <= 50 THEN 'E' ELSE 'I' END
UNION ALL
SELECT 'S vs N', 
       CASE WHEN m_s <= 50 THEN 'S' ELSE 'N' END,
       COUNT(*), 
       AVG(like_count),
       AVG(m_s)
FROM post WHERE m_s IS NOT NULL GROUP BY CASE WHEN m_s <= 50 THEN 'S' ELSE 'N' END
UNION ALL
SELECT 'T vs F', 
       CASE WHEN m_t <= 50 THEN 'T' ELSE 'F' END,
       COUNT(*), 
       AVG(like_count),
       AVG(m_t)
FROM post WHERE m_t IS NOT NULL GROUP BY CASE WHEN m_t <= 50 THEN 'T' ELSE 'F' END
UNION ALL
SELECT 'J vs P', 
       CASE WHEN m_j <= 50 THEN 'J' ELSE 'P' END,
       COUNT(*), 
       AVG(like_count),
       AVG(m_j)
FROM post WHERE m_j IS NOT NULL GROUP BY CASE WHEN m_j <= 50 THEN 'J' ELSE 'P' END;

CREATE VIEW user_mbti_stats AS
SELECT u.user_nickname, u.avg_m_e, u.avg_m_s, u.avg_m_t, u.avg_m_j, u.mbti_count,
       COUNT(p.id) as total_posts, AVG(p.like_count) as avg_post_likes
FROM user u LEFT JOIN post p ON u.user_nickname = p.user_nickname
GROUP BY u.user_nickname, u.avg_m_e, u.avg_m_s, u.avg_m_t, u.avg_m_j, u.mbti_count;

-- 10단계: 샘플 데이터 입력
-- 10-1: 사용자 데이터 먼저 입력
INSERT INTO user (userid, user_nickname, password) VALUES 
  ('hong', '홍길동', 'gil'),
  ('kim', '김철수', 'cul'),
  ('lee', '이영희', 'yeong');

-- 10-2: 사용자 MBTI 값 설정 (수치형)
UPDATE user 
SET avg_m_e = 80, avg_m_s = 20, avg_m_t = 70, avg_m_j = 30, mbti_count = 1 
WHERE user_nickname = '홍길동';

UPDATE user 
SET avg_m_e = 20, avg_m_s = 80, avg_m_t = 30, avg_m_j = 70, mbti_count = 1 
WHERE user_nickname = '김철수';

UPDATE user 
SET avg_m_e = 60, avg_m_s = 40, avg_m_t = 50, avg_m_j = 45, mbti_count = 1 
WHERE user_nickname = '이영희';

-- 외래키 체크 비활성화
SET FOREIGN_KEY_CHECKS = 0;

-- 데이터 입력 (수치형 MBTI)
INSERT INTO post (content, user_nickname, category, m_e, m_s, m_t, m_j) VALUES 
  ('첫 번째 게시글', '홍길동', '기타', 80, 20, 70, 30),
  ('두 번째 게시글', '김철수', '기쁨', 20, 80, 30, 70),
  ('세 번째 게시글', '이영희', '사랑', 60, 40, 50, 45);

INSERT INTO post_like (post_id, user_nickname) VALUES 
  (1, '홍길동'),
  (2, '김철수'),
  (1, '이영희');

-- 외래키 체크 다시 활성화
SET FOREIGN_KEY_CHECKS = 1;

-- 결과 확인
SELECT '=== 수치형 MBTI 데이터베이스 생성 완료 ===' as status;
SELECT '사용자 데이터:' as info;
SELECT * FROM user;
SELECT '게시글 데이터:' as info;
SELECT * FROM post;
SELECT '좋아요 데이터:' as info;
SELECT * FROM post_like;
SELECT 'MBTI 통계:' as info;
SELECT * FROM mbti_element_stats;

