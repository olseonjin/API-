// LikeServiceImpl.java
package com.boot.Service;

import com.boot.DAO.LikeDAO;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import java.util.HashMap;
import java.util.List;

@Service
@RequiredArgsConstructor
public class LikeServiceImpl implements LikeService {

    private final LikeDAO likeDAO;

    @Override
    public boolean addLike(HashMap<String, Object> param) {
        // 이미 눌렀으면 false, 아니면 true
        if (likeDAO.isLiked(param) > 0) return false;
        return likeDAO.addLike(param) > 0;
    }

    @Override
    public boolean removeLike(HashMap<String, Object> param) {
        // 눌렀을 때만 삭제
        if (likeDAO.isLiked(param) == 0) return false;
        return likeDAO.removeLike(param) > 0;
    }

    @Override
    public boolean isLiked(HashMap<String, Object> param) {
        return likeDAO.isLiked(param) > 0;
    }
    @Override
    public int countLikes(int postId) {
    return likeDAO.countLikes(postId);
    }
    @Override
    public List<String> getLikeUsers(int postId) {
    return likeDAO.getLikeUsers(postId);
    }
}