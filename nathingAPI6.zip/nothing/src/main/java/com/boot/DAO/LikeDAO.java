package com.boot.DAO;

import org.apache.ibatis.annotations.Mapper;
import java.util.HashMap;
import java.util.List;

@Mapper
public interface LikeDAO {
    int addLike(HashMap<String, Object> param);      // 좋아요 추가
    int removeLike(HashMap<String, Object> param);   // 좋아요 취소
    int isLiked(HashMap<String, Object> param);      // 이미 좋아요 눌렀는지 확인
    int countLikes(int postId);
    List<String> getLikeUsers(int postId);
}