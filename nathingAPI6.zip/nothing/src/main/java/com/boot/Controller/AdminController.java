package com.boot.Controller;

import com.boot.DTO.UserDTO;
import com.boot.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;
import java.util.List;

@Controller
@RequestMapping("/admin")
public class AdminController {

    @Autowired
    private UserService userService;

    // 관리자 대시보드
    @GetMapping("/dashboard")
    public String dashboard(HttpSession session, Model model) {
        // 세션에서 사용자 정보 확인
        UserDTO currentUser = (UserDTO) session.getAttribute("user");
        
        if (currentUser == null || !userService.isAdmin(currentUser)) {
            return "redirect:/login"; // 로그인 페이지로 리디렉션
        }

        // 모든 사용자 목록 조회
        List<UserDTO> users = userService.getAllUsers();
        model.addAttribute("users", users);
        
        return "admin/dashboard";
    }

    // 사용자 역할 변경
    @PostMapping("/update-role")
    @ResponseBody
    public String updateUserRole(@RequestParam int userId, 
                                @RequestParam String role, 
                                HttpSession session) {
        // 관리자 권한 확인
        UserDTO currentUser = (UserDTO) session.getAttribute("user");
        if (currentUser == null || !userService.isAdmin(currentUser)) {
            return "unauthorized";
        }

        try {
            userService.updateUserRole(userId, role);
            return "success";
        } catch (Exception e) {
            return "error";
        }
    }

    // 사용자 삭제
    @PostMapping("/delete-user")
    @ResponseBody
    public String deleteUser(@RequestParam int userId, HttpSession session) {
        // 관리자 권한 확인
        UserDTO currentUser = (UserDTO) session.getAttribute("user");
        if (currentUser == null || !userService.isAdmin(currentUser)) {
            return "unauthorized";
        }

        // 자기 자신은 삭제할 수 없음
        if (currentUser.getId() == userId) {
            return "cannot_delete_self";
        }

        try {
            userService.deleteUser(userId);
            return "success";
        } catch (Exception e) {
            return "error";
        }
    }


} 