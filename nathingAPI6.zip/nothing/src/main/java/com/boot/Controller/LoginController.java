package com.boot.Controller;

import com.boot.DTO.UserDTO;
import com.boot.Service.UserService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.*;

import javax.servlet.http.HttpSession;

@Controller
public class LoginController {

    @Autowired
    private UserService userService;

    // 로그인 폼 페이지
    @GetMapping("/login")
    public String showLoginForm() {
        return "login";
    }

    // 로그인 처리
    @PostMapping("/login")
    public String login(@RequestParam String username,
                       @RequestParam String password,
                       HttpSession session,
                       Model model) {
        
        try {
            // 로그인 검증
            UserDTO user = userService.login(username, password);
            
            if (user != null) {
                // 세션에 사용자 정보 저장
                session.setAttribute("user", user);
                
                // 관리자인 경우 관리자 대시보드로, 일반 사용자는 메인 페이지로
                if (userService.isAdmin(user)) {
                    return "redirect:/admin/dashboard";
                } else {
                    return "redirect:/"; // 메인 페이지로 리디렉션
                }
            } else {
                model.addAttribute("error", "아이디 또는 비밀번호가 올바르지 않습니다.");
                return "login";
            }
        } catch (Exception e) {
            model.addAttribute("error", "로그인 처리 중 오류가 발생했습니다.");
            return "login";
        }
    }

    // 로그아웃
    @GetMapping("/logout")
    public String logout(HttpSession session) {
        session.invalidate();
        return "redirect:/login";
    }

    // 메인 페이지 (로그인 후 접근)
    @GetMapping("/")
    public String main(HttpSession session, Model model) {
        UserDTO user = (UserDTO) session.getAttribute("user");
        if (user == null) {
            return "redirect:/login";
        }
        
        model.addAttribute("user", user);
        return "main";
    }
} 