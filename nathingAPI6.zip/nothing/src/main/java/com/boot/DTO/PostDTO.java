package com.boot.DTO;

import java.util.Date;

public class PostDTO {
    private int id;
    private String content;
    private String imageUrl;
    private String userNickname;
    private Date createdAt;
    private Date exitedAt;         // 종료 시간 추가
    private int likeCount;         // 좋아요 수 추가
    
    // MBTI 관련 필드들 추가
    private String category;       // 게시글 카테고리
    private String mE;            // E(외향) vs I(내향)
    private String mS;            // S(감각) vs N(직관)
    private String mT;            // T(사고) vs F(감정)
    private String mJ;            // J(판단) vs P(인식)

    public PostDTO() {}

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getUserNickname() { return userNickname; }
    public void setUserNickname(String userNickname) { this.userNickname = userNickname; }

    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }

    public Date getExitedAt() { return exitedAt; }
    public void setExitedAt(Date exitedAt) { this.exitedAt = exitedAt; }

    public int getLikeCount() { return likeCount; }
    public void setLikeCount(int likeCount) { this.likeCount = likeCount; }

    // MBTI 관련 getter/setter
    public String getCategory() { return category; }
    public void setCategory(String category) { this.category = category; }

    public String getME() { return mE; }
    public void setME(String mE) { this.mE = mE; }

    public String getMS() { return mS; }
    public void setMS(String mS) { this.mS = mS; }

    public String getMT() { return mT; }
    public void setMT(String mT) { this.mT = mT; }

    public String getMJ() { return mJ; }
    public void setMJ(String mJ) { this.mJ = mJ; }
}
