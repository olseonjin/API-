package com.boot.DTO;

import java.util.Date;

public class UserDTO {
    private int id;
    private String username;
    private String nickname;
    private String password;
    private String role; // 추가: 사용자 역할 (USER, ADMIN)
    private Date createdAt;
    
    // 평균 MBTI 관련 필드들 추가
    private String avgME;         // 평균 E vs I
    private String avgMS;         // 평균 S vs N
    private String avgMT;         // 평균 T vs F
    private String avgMJ;         // 평균 J vs P
    private int mbtiCount;        // MBTI 분석 횟수

    // 기본 생성자
    public UserDTO() {}

    // 전체 생성자
    public UserDTO(int id, String username, String nickname, String password, String role, Date createdAt) {
        this.id = id;
        this.username = username;
        this.nickname = nickname;
        this.password = password;
        this.role = role;
        this.createdAt = createdAt;
    }

    // Getters & Setters
    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getNickname() {
        return nickname;
    }

    public void setNickname(String nickname) {
        this.nickname = nickname;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }

    public String getRole() {
        return role;
    }

    public void setRole(String role) {
        this.role = role;
    }

    public Date getCreatedAt() {
        return createdAt;
    }

    public void setCreatedAt(Date createdAt) {
        this.createdAt = createdAt;
    }

    // MBTI 관련 getter/setter
    public String getAvgME() { return avgME; }
    public void setAvgME(String avgME) { this.avgME = avgME; }

    public String getAvgMS() { return avgMS; }
    public void setAvgMS(String avgMS) { this.avgMS = avgMS; }

    public String getAvgMT() { return avgMT; }
    public void setAvgMT(String avgMT) { this.avgMT = avgMT; }

    public String getAvgMJ() { return avgMJ; }
    public void setAvgMJ(String avgMJ) { this.avgMJ = avgMJ; }

    public int getMbtiCount() { return mbtiCount; }
    public void setMbtiCount(int mbtiCount) { this.mbtiCount = mbtiCount; }
}
