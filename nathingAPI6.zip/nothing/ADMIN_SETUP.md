# 관리자 계정 설정 가이드

## 1. 데이터베이스 업데이트

기존 user 테이블에 role 컬럼을 추가하고 관리자 계정을 생성합니다:

```sql
-- database_update.sql 파일의 내용을 실행하세요
ALTER TABLE user ADD COLUMN role VARCHAR(20) DEFAULT 'USER';
UPDATE user SET role = 'USER' WHERE role IS NULL;

-- 관리자 계정 생성 (비밀번호: admin123!)
INSERT INTO user (userid, user_nickname, password, role, created_at) 
VALUES ('admin', '관리자', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVEFDa', 'ADMIN', NOW());

CREATE INDEX idx_user_role ON user(role);
```

## 2. 관리자 계정 정보

- **아이디**: admin
- **비밀번호**: admin123!
- **닉네임**: 관리자
- **역할**: ADMIN

## 3. 관리자 기능

### 로그인 후 접근 가능한 기능:
- **사용자 관리**: 모든 사용자 목록 조회
- **역할 변경**: 일반 사용자 ↔ 관리자 역할 변경
- **사용자 삭제**: 사용자 계정 삭제 (자기 자신 제외)

### URL 경로:
- 관리자 대시보드: `/admin/dashboard`
- 로그인: `/login`
- 로그아웃: `/logout`

## 4. 보안 기능

- **세션 기반 인증**: 로그인 후 세션에 사용자 정보 저장
- **권한 검증**: 모든 관리자 기능에서 ADMIN 역할 확인
- **비밀번호 암호화**: BCrypt를 사용한 비밀번호 해싱
- **자기 삭제 방지**: 관리자가 자기 자신을 삭제할 수 없음

## 5. 역할 시스템

- **USER**: 일반 사용자 (기본값)
- **ADMIN**: 관리자 (모든 관리 기능 접근 가능)

## 6. 문제 해결

### 로그인이 안 되는 경우:
1. 비밀번호가 올바른지 확인 (admin123!)
2. 데이터베이스 연결 확인
3. BCrypt 라이브러리 의존성 확인

### 관리자 권한이 없는 경우:
1. 사용자의 role이 'ADMIN'인지 확인
2. 세션이 올바르게 설정되었는지 확인

## 7. 추가 관리자 계정 생성

다른 관리자 계정을 생성하려면:

```sql
-- 새로운 관리자 계정 생성
INSERT INTO user (userid, user_nickname, password, role, created_at) 
VALUES ('새관리자아이디', '새관리자닉네임', 'BCrypt암호화된비밀번호', 'ADMIN', NOW());
```

## 8. 추가 개발 사항

향후 추가할 수 있는 기능:
- 더 세분화된 권한 시스템 (SUPER_ADMIN, MODERATOR 등)
- Spring Security 통합
- JWT 토큰 기반 인증
- 로그인 시도 제한
- 비밀번호 정책 강화 