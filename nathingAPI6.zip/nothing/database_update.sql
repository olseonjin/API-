-- 기존 user 테이블에 role 컬럼 추가 (이미 있다면 무시)
ALTER TABLE user ADD COLUMN role VARCHAR(20) DEFAULT 'USER';

-- 기존 사용자들을 모두 USER 역할로 설정
UPDATE user SET role = 'USER' WHERE role IS NULL;

-- 관리자 계정 생성 (비밀번호: admin123!)
-- BCrypt로 암호화된 비밀번호 사용
INSERT INTO user (userid, user_nickname, password, role, created_at) 
VALUES ('admin', '관리자', '$2a$10$N.zmdr9k7uOCQb376NoUnuTJ8iAt6Z5EHsM8lE9lBOsl7iKTVEFDa', 'ADMIN', NOW());

-- role 컬럼에 인덱스 추가 (선택사항)
CREATE INDEX idx_user_role ON user(role); 