# MBTI 기능 사용 가이드

## 1. 기능 개요

이 시스템은 게시글의 내용을 분석하여 MBTI 성향을 파악하고, 사용자별 MBTI 통계를 제공합니다.

## 2. 주요 기능

### 2.1 MBTI 분석
- **경로**: `/mbti/analyze`
- **기능**: 게시글 작성 시 MBTI 4가지 요소 선택
- **MBTI 요소**:
  - E(외향) vs I(내향)
  - S(감각) vs N(직관)
  - T(사고) vs F(감정)
  - J(판단) vs P(인식)

### 2.2 감정 카테고리
- 기쁨, 슬픔, 분노, 두려움, 놀람, 혐오, 수치심, 죄책감, 사랑, 기대, 기타

### 2.3 MBTI 통계
- **경로**: `/mbti/stats`
- **기능**: MBTI 요소별 게시글 수와 평균 좋아요 수 통계

### 2.4 카테고리별 게시글
- **경로**: `/mbti/category/{category}`
- **기능**: 특정 감정 카테고리의 게시글 조회

### 2.5 사용자별 MBTI 통계
- **경로**: `/mbti/user-stats`
- **기능**: 개인의 평균 MBTI 성향과 분석 횟수 확인

## 3. 데이터베이스 구조

### 3.1 POST 테이블 추가 컬럼
```sql
category VARCHAR(50) DEFAULT '일반'     -- 게시글 카테고리
m_e VARCHAR(1)                        -- E(외향) vs I(내향)
m_s VARCHAR(1)                        -- S(감각) vs N(직관)
m_t VARCHAR(1)                        -- T(사고) vs F(감정)
m_j VARCHAR(1)                        -- J(판단) vs P(인식)
```

### 3.2 USER 테이블 추가 컬럼
```sql
avg_m_e VARCHAR(1)                    -- 평균 E vs I
avg_m_s VARCHAR(1)                    -- 평균 S vs N
avg_m_t VARCHAR(1)                    -- 평균 T vs F
avg_m_j VARCHAR(1)                    -- 평균 J vs P
mbti_count INT DEFAULT 0              -- MBTI 분석 횟수
```

## 4. 사용 방법

### 4.1 MBTI 분석하기
1. `/mbti/analyze` 접속
2. 게시글 내용 입력
3. 감정 카테고리 선택
4. MBTI 4가지 요소 각각 선택
5. "MBTI 분석하기" 버튼 클릭

### 4.2 통계 확인하기
1. `/mbti/stats`에서 전체 MBTI 통계 확인
2. `/mbti/user-stats`에서 개인 MBTI 통계 확인
3. `/mbti/category/{카테고리}`에서 특정 감정의 게시글 확인

## 5. 자동 업데이트

### 5.1 사용자 평균 MBTI
- 게시글 작성 시 자동으로 사용자의 평균 MBTI 업데이트
- 3개 이상의 게시글이 있을 때 최빈값 사용
- 3개 미만일 때는 최신 게시글의 MBTI 사용

### 5.2 게시글 만료 시간
- 게시글 작성 시 `exited_at`이 현재 시간 + 1분으로 자동 설정
- 1분 후 게시글 자동 만료

## 6. API 엔드포인트

| 메서드 | 경로 | 설명 |
|--------|------|------|
| GET | `/mbti/stats` | MBTI 통계 대시보드 |
| GET | `/mbti/analyze` | MBTI 분석 페이지 |
| POST | `/mbti/analyze` | MBTI 분석 처리 |
| GET | `/mbti/category/{category}` | 카테고리별 게시글 |
| GET | `/mbti/user-stats` | 사용자별 MBTI 통계 |
| GET | `/mbti/element/{element}` | MBTI 요소별 상세 분석 |

## 7. 예시 데이터

### 7.1 MBTI 분석 결과
```json
{
  "content": "오늘 친구들과 놀러가서 정말 재미있었어요!",
  "category": "기쁨",
  "mE": "E",
  "mS": "S", 
  "mT": "F",
  "mJ": "P"
}
```

### 7.2 사용자 평균 MBTI
```json
{
  "username": "user123",
  "avgME": "E",
  "avgMS": "N",
  "avgMT": "F", 
  "avgMJ": "J",
  "mbtiCount": 5
}
```

## 8. 주의사항

1. **로그인 필요**: MBTI 분석은 로그인한 사용자만 가능
2. **데이터 정확성**: MBTI는 사용자가 직접 선택하는 방식
3. **통계 업데이트**: 게시글 작성 시 실시간으로 통계 업데이트
4. **게시글 만료**: 모든 게시글은 1분 후 자동 만료

## 9. 향후 개선 사항

- AI 기반 자동 MBTI 분석
- 더 세분화된 감정 카테고리
- MBTI 호환성 분석
- 실시간 MBTI 채팅방
- MBTI 기반 추천 시스템

