// LikeService.java
package com.boot.Service;

import java.util.HashMap;
import java.util.List;

public interface LikeService {
    boolean addLike(HashMap<String, Object> param);
    boolean removeLike(HashMap<String, Object> param);
    boolean isLiked(HashMap<String, Object> param);
    int countLikes(int postId);
    List<String> getLikeUsers(int postId);
}