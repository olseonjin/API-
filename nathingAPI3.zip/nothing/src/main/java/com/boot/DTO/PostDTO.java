package com.boot.DTO;

import java.util.Date;

public class PostDTO {
    private int id;
    private String content;
    private String imageUrl;
    private String userNickname;
    private Date createdAt;
    private Date exitedAt;         // 종료 시간 추가
    private int likeCount;         // 좋아요 수 추가

    public PostDTO() {}

    // Getters & Setters
    public int getId() { return id; }
    public void setId(int id) { this.id = id; }

    public String getContent() { return content; }
    public void setContent(String content) { this.content = content; }

    public String getImageUrl() { return imageUrl; }
    public void setImageUrl(String imageUrl) { this.imageUrl = imageUrl; }

    public String getUserNickname() { return userNickname; }
    public void setUserNickname(String userNickname) { this.userNickname = userNickname; }

    public Date getCreatedAt() { return createdAt; }
    public void setCreatedAt(Date createdAt) { this.createdAt = createdAt; }

    public Date getExitedAt() { return exitedAt; }
    public void setExitedAt(Date exitedAt) { this.exitedAt = exitedAt; }

    public int getLikeCount() { return likeCount; }
    public void setLikeCount(int likeCount) { this.likeCount = likeCount; }
}
